package Interface;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.Servlet;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class InterfaceDemo implements Servlet {
    ServletConfig config=null;
    
    @Override
	public void init(ServletConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
        this.config=config;
        System.out.println("Initialization complete");

	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("In destroy() method");
	}

	@Override
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return config;
	}

	@Override
	public String getServletInfo() {
		// TODO Auto-generated method stub
        return "This is a sample servlet info";
	}

	@Override
	public void service(ServletRequest arg0, ServletResponse arg1) throws ServletException, IOException {
		ServletResponse res = null;
		// TODO Auto-generated method stub
        res.setContentType("text/html");
        PrintWriter pwriter=res.getWriter();
        pwriter.print("<html>");
        pwriter.print("<body>");
        pwriter.print("In the service() method<br>");
        pwriter.print("</body>");
        pwriter.print("</html>");

	}

}
