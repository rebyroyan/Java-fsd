package practiceproject2;

public class priAccessSpecifier {
	private void display() 
    { 
        System.out.println("You are using private access specifier"); 
    } 
}
