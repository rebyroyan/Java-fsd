package practiceproject2;

public class accessSpecifiers4 {
public static void main(String[] args) {
		
		pubAccessSpecifiers obj = new pubAccessSpecifiers(); 
        obj.display();  
		
	}
}
