package practiceproject2;

public class proAccessSpecifiers {
	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}
