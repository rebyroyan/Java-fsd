package practiceproject2;

public class accsessSpecifier3 extends proAccessSpecifiers{
	public static void main(String[] args) {
		proAccessSpecifiers obj = new proAccessSpecifiers();   
	       obj.display();  
	}
}
