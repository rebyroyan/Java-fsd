import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
    imports: [
      FormsModule,
      ReactiveFormsModule
      // other imports
    ],
    // other declarations and providers
  })
  export class AppModule { }
  